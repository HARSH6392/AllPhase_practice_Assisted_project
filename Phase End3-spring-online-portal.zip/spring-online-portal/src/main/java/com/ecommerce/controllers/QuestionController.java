package com.ecommerce.controllers;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.ecommerce.entity.Question;
import com.ecommerce.repository.QuestionRepo;

@Controller
public class QuestionController {

	@Autowired
	QuestionRepo questionRepo;
	
	@GetMapping("/add-question")
	public String showNewQuestionForm(Model model)
	{
		Question question = new Question();
		model.addAttribute("question", question);

		return "new-question";
	}
	
	@PostMapping("/add-question")
	public String addNewQuestion(@ModelAttribute("question") Question question)
	{
		questionRepo.save(question);
		return "admin-dashboard";
	}
	
	//List all Questions
	@GetMapping("/view-questions")
	public String listQuestions(Model model)
	{
		List<Question> questionList = questionRepo.findAll();
		model.addAttribute("questionList", questionList);
		
		return "question-list";
	}
	
	// Delete functionality
	@GetMapping("/delete-question")
	public String deleteQuestion(@RequestParam int id, Model model)
	{
		Optional<Question> questionFromRepo = questionRepo.findById(id);
			questionRepo.deleteById(id);
			model.addAttribute("id", id);
			return "admin-dashboard"; // go to delete-product-success.jsp			

	}
	
	@GetMapping("/update-question")
	public String showEditQuestionForm(@RequestParam int id, Model model)
	{
		Optional<Question> questionFromRepo = questionRepo.findById(id);
		Question question = questionFromRepo.get();
		model.addAttribute("question", question);
		return "update-question";
	}
	
	@PostMapping("/update-question")
	public String updateProduct(@ModelAttribute("question") Question question)
	{
		questionRepo.save(question);
		return "admin-dashboard";
	}
}
