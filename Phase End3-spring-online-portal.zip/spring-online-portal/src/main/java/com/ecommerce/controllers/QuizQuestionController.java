package com.ecommerce.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.entity.Question;
import com.ecommerce.entity.Quiz;
import com.ecommerce.repository.QuestionRepo;
import com.ecommerce.repository.QuizRepo;

import org.springframework.ui.Model;


@Controller
public class QuizQuestionController {
	
	@Autowired
	QuizRepo  quizRepo;
	
	@Autowired
	QuestionRepo questionRepo;
	
	


}
