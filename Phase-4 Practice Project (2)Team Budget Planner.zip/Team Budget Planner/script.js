class Deal {
    constructor(teamName, vendorName, dealAmount) {
      this.teamName = teamName;
      this.vendorName = vendorName;
      this.dealAmount = dealAmount;
    }
  }
  
  class Budget {
    constructor() {
      this.deals = [];
    }
  
    addDeal(teamName, vendorName, dealAmount) {
      const deal = new Deal(teamName, vendorName, dealAmount);
      this.deals.push(deal);
    }
  
    removeDeal(teamName, vendorName) {
      this.deals = this.deals.filter(deal => deal.teamName !== teamName || deal.vendorName !== vendorName);
    }
  
    getTotalBudget() {
      return this.deals.reduce((total, deal) => total + deal.dealAmount, 0);
    }
  
    getAverageDealAmount() {
      const totalAmount = this.getTotalBudget();
      return totalAmount / this.deals.length || 0;
    }
  }
  
  function displayBudgetSummary() {
    const dealList = document.getElementById("dealList");
    const totalBudget = document.getElementById("totalBudget");
    const averageAmount = document.getElementById("averageAmount");
  
    dealList.innerHTML = "";
    totalBudget.textContent = "";
    averageAmount.textContent = "";
  
    budget.deals.forEach(function (deal) {
      const listItem = document.createElement("li");
      listItem.textContent = `Team: ${deal.teamName}, Vendor: ${deal.vendorName}, Amount: $${deal.dealAmount}`;
      listItem.dataset.teamName = deal.teamName;
      listItem.dataset.vendorName = deal.vendorName;
  
      const deleteButton = document.createElement("button");
      deleteButton.textContent = "Delete";
      deleteButton.classList.add("delete-deal");
  
      listItem.appendChild(deleteButton);
      dealList.appendChild(listItem);
    });
  
    totalBudget.textContent = `Total Budget: $${budget.getTotalBudget()}`;
    averageAmount.textContent = `Average Deal Amount: $${budget.getAverageDealAmount().toFixed(2)}`;
  }
  
  const budget = new Budget();
  
  document.getElementById("budgetForm").addEventListener("submit", function (event) {
    event.preventDefault();
  
    const teamName = document.getElementById("teamName").value;
    const vendorName = document.getElementById("vendorName").value;
    const dealAmount = parseFloat(document.getElementById("dealAmount").value);
  
    if (dealAmount > 0) {
      budget.addDeal(teamName, vendorName, dealAmount);
      document.getElementById("teamName").value = "";
      document.getElementById("vendorName").value = "";
      document.getElementById("dealAmount").value = "";
      displayBudgetSummary();
    } else {
      alert("Deal amount must be a positive number.");
    }
  });
  
  document.getElementById("budgetSummary").addEventListener("click", function (event) {
    if (event.target.classList.contains("delete-deal")) {
      const listItem = event.target.parentElement;
      const teamName = listItem.dataset.teamName;
      const vendorName = listItem.dataset.vendorName;
      budget.removeDeal(teamName, vendorName);
      displayBudgetSummary();
    }
  });
  
  displayBudgetSummary();
  